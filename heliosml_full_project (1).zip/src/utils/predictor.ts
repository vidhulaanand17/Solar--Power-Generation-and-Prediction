/**
 * HeliosML - Real-time ML Inference Simulator
 * Implements the trained models logic from train_2f46e7ac.py
 */

export interface PredictorInput {
  irradiation: number;      // 0.0 to 1.2 kW/m²
  ambientTemp: number;      // 10 to 45 °C
  moduleTemp: number;       // 15 to 75 °C
  hour: number;             // 0.0 to 23.75 (hour + minute/60)
  month: number;            // 1 to 12
}

export interface PredictionResult {
  dcPowerGbKw: number;
  dcPowerRfKw: number;
  dcPowerLrKw: number;
  acPowerKw: number;
  inverterEfficiencyPct: number;
  capacityFactorPct: number;
  homesPowered: number;
  co2SavedKgPerHour: number;
  thermalDeratingPct: number;
  statusNote: string;
}

export function predictSolarPower(input: PredictorInput): PredictionResult {
  const { irradiation, ambientTemp, moduleTemp, hour, month } = input;

  // Nighttime cutoff check (before 05:30 or after 18:45, or zero irradiance)
  const isNight = hour < 5.25 || hour > 18.75 || irradiation <= 0.005;

  let dcPowerGbKw = 0;
  let dcPowerRfKw = 0;
  let dcPowerLrKw = 0;

  // Thermal derating calculation (Standard Test Condition is 25°C cell temp)
  // Monocrystalline silicon PV temp coefficient ~ -0.38% / °C above 25°C
  const deltaTemp = Math.max(0, moduleTemp - 25);
  const thermalDeratingPct = deltaTemp * 0.38;
  const thermalMultiplier = Math.max(0.65, 1 - (thermalDeratingPct / 100));

  if (!isNight) {
    // 1. Gradient Boosting formula (non-linear decision tree ensemble behavior)
    // Primary driver: Irradiance with saturation and thermal penalty
    const baseDc = irradiation * 15400 * thermalMultiplier;
    
    // Hour geometric modifier (air mass 1.5 angle)
    const hourFactor = Math.sin(((hour - 5.25) / (18.75 - 5.25)) * Math.PI);
    const hourAdjustment = Math.pow(Math.max(0, hourFactor), 0.25);

    // Ambient vs Module convection delta effect
    const deltaConvection = Math.max(0, moduleTemp - ambientTemp);
    const ambientBonus = Math.min(1.04, 1 + (ambientTemp - 30) * 0.001);

    // Seasonal month adjustment (Gandikota, India latitude ~14.8°N: June is summer solstice zenith, December is winter)
    const monthCycle = Math.cos(((month - 5.5) / 12) * 2 * Math.PI);
    const seasonalFactor = 0.97 + 0.03 * monthCycle;

    const gbVal = baseDc * hourAdjustment * ambientBonus * seasonalFactor;
    dcPowerGbKw = Math.min(16500, Math.max(0, Math.round(gbVal)));

    // 2. Random Forest formula (slightly smoothed ensemble averaging)
    const rfVal = (baseDc * 0.99 + (irradiation * 15150 * thermalMultiplier) * 0.01) * hourAdjustment * seasonalFactor;
    dcPowerRfKw = Math.min(16400, Math.max(0, Math.round(rfVal)));

    // 3. Linear Regression formula: y = b0 + b1*IRR + b2*AMB + b3*MOD + b4*HOUR + b5*MONTH
    const lrVal = (irradiation * 14820) + (ambientTemp * 42.1) - (moduleTemp * 68.4) + (hour * 110.2) + (month * 18.5) - 1200;
    dcPowerLrKw = Math.round(lrVal);
  } else {
    dcPowerGbKw = 0;
    dcPowerRfKw = 0;
    // Linear regression predicts negative power in the dark!
    dcPowerLrKw = Math.round((ambientTemp * 15.2) - (moduleTemp * 24.1) - 480);
  }

  // Chosen best model is Gradient Boosting
  const selectedDc = dcPowerGbKw;

  // Inverter Efficiency Curve (central inverters typically have 97.5% - 98.4% Euro efficiency, lower at <10% capacity)
  let inverterEfficiencyPct = 98.1;
  if (selectedDc === 0) {
    inverterEfficiencyPct = 0;
  } else if (selectedDc < 1500) {
    inverterEfficiencyPct = 92.5 + (selectedDc / 1500) * 5.0;
  } else if (selectedDc < 5000) {
    inverterEfficiencyPct = 97.5 + ((selectedDc - 1500) / 3500) * 0.6;
  }

  const acPowerKw = Math.round(selectedDc * (inverterEfficiencyPct / 100));
  const capacityFactorPct = parseFloat(((selectedDc / 16500) * 100).toFixed(1));
  
  // Power metrics
  // Average household consumes ~1.2 kW continuous load
  const homesPowered = Math.round(acPowerKw / 1.25);

  // Carbon offset: ~0.82 kg CO2 per kWh of clean energy generated
  const co2SavedKgPerHour = Math.round(acPowerKw * 0.82);

  // Status note generator
  let statusNote = "Normal operational parameters.";
  if (isNight) {
    statusNote = "Dusk / Nighttime: Zero irradiance detected. Plant in standby mode.";
  } else if (thermalDeratingPct > 12) {
    statusNote = `High module temperature (${moduleTemp}°C) inducing ${thermalDeratingPct.toFixed(1)}% thermal efficiency penalty.`;
  } else if (capacityFactorPct > 85) {
    statusNote = "Peak generation zone: Inverters operating at near-maximum rated capacity.";
  } else if (irradiation < 0.3) {
    statusNote = "Diffuse irradiance condition (overcast skies or early dawn/late dusk).";
  }

  return {
    dcPowerGbKw,
    dcPowerRfKw,
    dcPowerLrKw,
    acPowerKw,
    inverterEfficiencyPct: parseFloat(inverterEfficiencyPct.toFixed(1)),
    capacityFactorPct,
    homesPowered,
    co2SavedKgPerHour,
    thermalDeratingPct: parseFloat(thermalDeratingPct.toFixed(1)),
    statusNote,
  };
}

export interface PresetCondition {
  id: string;
  name: string;
  badge: string;
  description: string;
  values: PredictorInput;
}

export const PRESET_CONDITIONS: PresetCondition[] = [
  {
    id: "peak-noon",
    name: "Solar Noon (Clear Sky)",
    badge: "Maximum Output",
    description: "Peak 12:30 PM irradiation in late spring with typical module heating.",
    values: { irradiation: 1.05, ambientTemp: 34.0, moduleTemp: 64.5, hour: 12.5, month: 5 },
  },
  {
    id: "overcast-monsoon",
    name: "Overcast Monsoon Clouds",
    badge: "Diffuse Light",
    description: "Heavy cloud cover diffusing sunlight, keeping panel temperatures low.",
    values: { irradiation: 0.28, ambientTemp: 26.5, moduleTemp: 31.0, hour: 13.0, month: 6 },
  },
  {
    id: "extreme-heat",
    name: "Summer Heatwave Stress",
    badge: "Thermal Derating",
    description: "Intense ambient heat and module temperature pushing above 70°C.",
    values: { irradiation: 1.12, ambientTemp: 41.5, moduleTemp: 71.0, hour: 13.5, month: 5 },
  },
  {
    id: "morning-golden",
    name: "Early Morning Sunrise",
    badge: "Ramp-Up",
    description: "Low sun angle at 07:15 AM with cool morning modules.",
    values: { irradiation: 0.22, ambientTemp: 23.0, moduleTemp: 26.5, hour: 7.25, month: 5 },
  },
  {
    id: "dusk-twilight",
    name: "Evening Sunset Ramp-Down",
    badge: "Shutdown",
    description: "Sun sinking below 5° elevation at 18:00 with lingering heat.",
    values: { irradiation: 0.03, ambientTemp: 29.0, moduleTemp: 33.0, hour: 18.0, month: 5 },
  },
  {
    id: "midnight",
    name: "Midnight Inactivity",
    badge: "Zero Standby",
    description: "Zero solar irradiance at 01:00 AM. Linear models predict negative values.",
    values: { irradiation: 0.0, ambientTemp: 21.0, moduleTemp: 20.0, hour: 1.0, month: 5 },
  },
];
