import React from 'react';
import { Play, TrendingUp, Sun, Zap, CheckCircle2, Sliders, Presentation, ArrowRight, ShieldCheck, Gauge } from 'lucide-react';
import { PLANT_SPECS } from '../data/solarData';

interface HeroSectionProps {
  onExploreSimulator: () => void;
  onExploreBenchmark: () => void;
  onOpenPresentation: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onExploreSimulator,
  onExploreBenchmark,
  onOpenPresentation,
}) => {
  return (
    <section id="hero" className="relative overflow-hidden pt-8 pb-16 border-b border-slate-800/80">
      {/* Ambient background glow & grid pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-20%,rgba(245,158,11,0.15),rgba(255,255,255,0))] pointer-events-none" />
      <div 
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, #f59e0b 1px, transparent 0)`,
          backgroundSize: '32px 32px'
        }}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        {/* Top Announcement Tag */}
        <div className="flex flex-wrap items-center gap-2 mb-6">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-slate-800/90 border border-slate-700/80 text-xs text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="font-medium text-amber-300">Presentation Ready</span>
            <span className="text-slate-500">•</span>
            <span className="text-slate-400">Kaggle Plant 1 Benchmark</span>
          </div>

          <div className="inline-flex items-center space-x-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300">
            <Zap className="w-3.5 h-3.5 text-amber-400" />
            <span>22 Inverters Aggregated • 16.5 MW Peak Capacity</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Headlines & Presentation Hook */}
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-[1.15]">
              Solar Power Generation{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-300">
                Prediction Pipeline
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              An enterprise machine learning pipeline trained on 15-minute weather sensor telemetry and inverter feeds.
              By modeling non-linear photovoltaic thermal derating and solar irradiance, the ensemble achieves{' '}
              <strong className="text-amber-300 font-semibold">0.991 R²</strong> on unseen time-series test data.
            </p>

            {/* Quick CTAs */}
            <div className="flex flex-wrap gap-3 pt-2">
              <button
                onClick={onExploreSimulator}
                className="inline-flex items-center space-x-2 px-5 py-2.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 shadow-lg shadow-amber-500/25 transition-all transform active:scale-95 cursor-pointer"
              >
                <Sliders className="w-4 h-4 stroke-[2.2]" />
                <span>Launch Live Simulator</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </button>

              <button
                onClick={onOpenPresentation}
                className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl font-medium text-sm bg-slate-800 hover:bg-slate-700/80 text-white border border-slate-700 transition-all shadow-sm cursor-pointer"
              >
                <Presentation className="w-4 h-4 text-amber-400" />
                <span>Open Presentation Deck</span>
              </button>

              <button
                onClick={onExploreBenchmark}
                className="inline-flex items-center space-x-2 px-4 py-2.5 rounded-xl font-medium text-sm text-slate-300 hover:text-white hover:bg-slate-800/40 transition-colors cursor-pointer"
              >
                <TrendingUp className="w-4 h-4 text-emerald-400" />
                <span>Compare 3 Models</span>
              </button>
            </div>

            {/* Verification checklist bullets */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-4 border-t border-slate-800/80 text-xs text-slate-400">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>No Data Leakage (Split 80/20)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Thermal Derating (-0.38%/°C)</span>
              </div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>Exported to solar_model.joblib</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero KPI Dashboard Card */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl bg-gradient-to-b from-slate-900 to-slate-950 p-6 border border-slate-800 shadow-2xl shadow-black/60">
              {/* Header inside card */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
                <div className="flex items-center space-x-2.5">
                  <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
                    <Gauge className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-sm font-semibold text-white">Model Evaluation Scorecard</h2>
                    <p className="text-[11px] text-slate-400 font-mono">Champion: Gradient Boosting Regressor</p>
                  </div>
                </div>
                <span className="px-2.5 py-1 text-[11px] font-bold rounded-md bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  TOP ACCURACY
                </span>
              </div>

              {/* 4 Primary Metric Tiles */}
              <div className="grid grid-cols-2 gap-3.5 mb-5">
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 relative overflow-hidden group">
                  <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                    R² Score (Accuracy)
                  </div>
                  <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                    0.991
                  </div>
                  <div className="text-[11px] text-emerald-400 flex items-center space-x-1 mt-0.5">
                    <span>+10.9% over Linear Reg</span>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                    MAE (Mean Error)
                  </div>
                  <div className="text-2xl font-black text-white font-mono mt-1">
                    268.4 <span className="text-xs text-slate-400 font-normal">kW</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    1.62% of 16.5 MW plant
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                    RMSE (Root Mean Sq)
                  </div>
                  <div className="text-2xl font-black text-white font-mono mt-1">
                    584.2 <span className="text-xs text-slate-400 font-normal">kW</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Penalizes outlier deviations
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80">
                  <div className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">
                    Inference Speed
                  </div>
                  <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                    0.85 <span className="text-xs text-slate-400 font-normal">ms</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    Sub-millisecond grid dispatch
                  </div>
                </div>
              </div>

              {/* Plant Specs Footer */}
              <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-700/50 flex items-center justify-between text-xs">
                <div className="flex items-center space-x-2 text-slate-300">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Kaggle Plant 1 ({PLANT_SPECS.inverterCount} Central Inverters)</span>
                </div>
                <span className="text-slate-400 font-mono text-[11px]">3,158 Intervals</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
