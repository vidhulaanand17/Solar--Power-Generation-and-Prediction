import React, { useState } from 'react';
import { Database, Search, Filter, Server, ArrowDownUp, CheckCircle, Info } from 'lucide-react';
import { SAMPLE_KAGGLE_RECORDS, PLANT_SPECS } from '../data/solarData';

export const DatasetExplorer: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredRecords = SAMPLE_KAGGLE_RECORDS.filter(
    (r) =>
      r.inverterId.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.dateTime.includes(searchTerm)
  );

  return (
    <section id="dataset" className="py-16 border-b border-slate-800/80 bg-slate-900/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 font-medium mb-2">
              <Database className="w-3.5 h-3.5" />
              <span>Plant 1 Telemetry Corpus</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Kaggle Dataset & Plant Architecture
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Inspect the raw multi-inverter telemetry collected across 34 days from Gandikota Solar Plant (Plant 1), combined with pyranometer weather station feeds.
            </p>
          </div>

          <div className="flex items-center space-x-3 text-xs font-mono text-slate-400">
            <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800">
              68,778 Inverter Rows
            </span>
            <span>→</span>
            <span className="px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
              3,158 Aggregated Timestamps
            </span>
          </div>
        </div>

        {/* 4 Technical Architecture Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400 uppercase font-mono">Inverter Farm</div>
            <div className="text-xl font-bold text-white mt-1">22 Inverters</div>
            <p className="text-[11px] text-slate-400 mt-1">Central string inverters summed into total plant DC output.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400 uppercase font-mono">Sensor Logging</div>
            <div className="text-xl font-bold text-amber-400 mt-1">15-Min Cadence</div>
            <p className="text-[11px] text-slate-400 mt-1">96 uniform time steps per day capturing continuous solar arcs.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400 uppercase font-mono">Duration & Season</div>
            <div className="text-xl font-bold text-white mt-1">34 Days (May–Jun)</div>
            <p className="text-[11px] text-slate-400 mt-1">High solar irradiance window with summer convective clouds.</p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800">
            <div className="text-[11px] text-slate-400 uppercase font-mono">Split Strategy</div>
            <div className="text-xl font-bold text-emerald-400 mt-1">80% Train / 20% Test</div>
            <p className="text-[11px] text-slate-400 mt-1">Strict chronological split preventing future data leakage.</p>
          </div>
        </div>

        {/* Interactive Sample Records Table */}
        <div className="rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-xl">
          <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex flex-col sm:flex-row justify-between sm:items-center gap-3">
            <div className="flex items-center space-x-2">
              <Server className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Raw Telemetry Sample Preview (Plant 1)
              </span>
            </div>

            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search timestamp or inverter ID..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 w-full sm:w-64"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900/60 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-3 px-4">DATE_TIME</th>
                  <th className="py-3 px-4">SOURCE_KEY (Inverter)</th>
                  <th className="py-3 px-4 text-right">DC_POWER (kW)</th>
                  <th className="py-3 px-4 text-right">AC_POWER (kW)</th>
                  <th className="py-3 px-4 text-right">IRRADIATION (kW/m²)</th>
                  <th className="py-3 px-4 text-right">AMBIENT_TEMP (°C)</th>
                  <th className="py-3 px-4 text-right">MODULE_TEMP (°C)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                {filteredRecords.map((rec, i) => (
                  <tr key={i} className="hover:bg-slate-900/40 transition-colors">
                    <td className="py-2.5 px-4 text-slate-400">{rec.dateTime}</td>
                    <td className="py-2.5 px-4 text-amber-300 font-semibold">{rec.inverterId}</td>
                    <td className="py-2.5 px-4 text-right text-emerald-400 font-bold">{rec.dcPower.toFixed(1)}</td>
                    <td className="py-2.5 px-4 text-right text-white">{rec.acPower.toFixed(1)}</td>
                    <td className="py-2.5 px-4 text-right text-amber-400">{rec.irradiation.toFixed(3)}</td>
                    <td className="py-2.5 px-4 text-right text-sky-400">{rec.ambientTemp.toFixed(1)}</td>
                    <td className="py-2.5 px-4 text-right text-rose-400">{rec.moduleTemp.toFixed(1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-slate-900/40 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Showing top 10 synchronized rows of Plant 1 merged dataframe</span>
            <span className="font-mono text-amber-400">Total inverters: 22 feeds combined</span>
          </div>
        </div>
      </div>
    </section>
  );
};
