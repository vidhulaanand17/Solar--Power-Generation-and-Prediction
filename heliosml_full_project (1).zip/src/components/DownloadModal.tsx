import React, { useState } from 'react';
import { X, Download, FileCode, Archive, FileText, Check, ExternalLink, Printer, Terminal, Sparkles } from 'lucide-react';
import JSZip from 'jszip';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenPresentation: () => void;
}

const TRAIN_PY_CONTENT = `"""
Solar Power Generation Prediction - training script

Dataset: Kaggle "Solar Power Generation Data" (Plant 1)
Put these two files in the same folder as this script:
    Plant_1_Generation_Data.csv
    Plant_1_Weather_Sensor_Data.csv

Run:  python train.py
"""

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ---------------------------------------------------------------- 1. Load
gen = pd.read_csv("Plant_1_Generation_Data.csv")
weather = pd.read_csv("Plant_1_Weather_Sensor_Data.csv")

# The two files use different date formats
gen["DATE_TIME"] = pd.to_datetime(gen["DATE_TIME"], dayfirst=True)
weather["DATE_TIME"] = pd.to_datetime(weather["DATE_TIME"])

# Total plant output per timestamp (sum over all inverters)
gen = gen.groupby("DATE_TIME", as_index=False)["DC_POWER"].sum()

df = gen.merge(
    weather[["DATE_TIME", "AMBIENT_TEMPERATURE", "MODULE_TEMPERATURE", "IRRADIATION"]],
    on="DATE_TIME",
    how="inner",
).sort_values("DATE_TIME")

# ---------------------------------------------------------------- 2. Clean + features
df = df.dropna()
df["hour"] = df["DATE_TIME"].dt.hour + df["DATE_TIME"].dt.minute / 60
df["month"] = df["DATE_TIME"].dt.month

FEATURES = ["IRRADIATION", "AMBIENT_TEMPERATURE", "MODULE_TEMPERATURE", "hour", "month"]
TARGET = "DC_POWER"

# ---------------------------------------------------------------- 3. Time-based split (no shuffling)
split = int(len(df) * 0.8)
train, test = df.iloc[:split], df.iloc[split:]
X_train, y_train = train[FEATURES], train[TARGET]
X_test, y_test = test[FEATURES], test[TARGET]

# ---------------------------------------------------------------- 4. Models
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1),
    "Gradient Boosting": GradientBoostingRegressor(random_state=42),
}

results, preds = {}, {}
for name, model in models.items():
    model.fit(X_train, y_train)
    p = model.predict(X_test)
    preds[name] = p
    results[name] = {
        "RMSE": np.sqrt(mean_squared_error(y_test, p)),
        "MAE": mean_absolute_error(y_test, p),
        "R2": r2_score(y_test, p),
    }

results_df = pd.DataFrame(results).T.round(3)
print("\\nModel comparison:\\n", results_df)

best_name = results_df["R2"].idxmax()
best_model = models[best_name]
print(f"\\nBest model: {best_name}")

joblib.dump({"model": best_model, "features": FEATURES}, "solar_model.joblib")

# ---------------------------------------------------------------- 5. Plots
# Actual vs predicted (last 3 days of test set)
n = 96 * 3  # 15-min data -> 96 points per day
plt.figure(figsize=(11, 4))
plt.plot(test["DATE_TIME"].iloc[-n:], y_test.iloc[-n:], label="Actual")
plt.plot(test["DATE_TIME"].iloc[-n:], preds[best_name][-n:], label=f"Predicted ({best_name})")
plt.ylabel("DC power (kW)")
plt.title("Actual vs predicted solar power")
plt.legend()
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)

# Feature importance (tree models only)
if hasattr(best_model, "feature_importances_"):
    imp = pd.Series(best_model.feature_importances_, index=FEATURES).sort_values()
    plt.figure(figsize=(6, 3.5))
    imp.plot(kind="barh")
    plt.title("Feature importance")
    plt.tight_layout()
    plt.savefig("feature_importance.png", dpi=150)

# Daily pattern
plt.figure(figsize=(7, 3.5))
df.groupby(df["DATE_TIME"].dt.hour)[TARGET].mean().plot()
plt.xlabel("Hour of day")
plt.ylabel("Mean DC power (kW)")
plt.title("Average daily generation profile")
plt.tight_layout()
plt.savefig("daily_profile.png", dpi=150)

print("\\nSaved: solar_model.joblib, actual_vs_predicted.png, feature_importance.png, daily_profile.png")
`;

const REQUIREMENTS_TXT = `pandas>=2.0.0
numpy>=1.24.0
scikit-learn>=1.4.0
matplotlib>=3.8.0
joblib>=1.3.0
`;

const README_MD = `# HeliosML: Solar Power Generation Prediction

Machine Learning pipeline for predicting solar generation at utility scale, trained on Kaggle's **Solar Power Generation Data (Plant 1)**.

## Project Structure
- \`train.py\`: Full data loading, cleaning, feature engineering, ensemble training, evaluation, and visualization script.
- \`requirements.txt\`: Python dependencies.
- \`solar_model.joblib\`: Serialized Gradient Boosting model.
- \`actual_vs_predicted.png\`: 3-day time-series evaluation plot.
- \`feature_importance.png\`: Relative feature importance plot.
- \`daily_profile.png\`: 24-hour diurnal power generation curve.

## Kaggle Dataset
Download the two CSV files from Kaggle ("Solar Power Generation Data") and place them in the same folder:
1. \`Plant_1_Generation_Data.csv\`
2. \`Plant_1_Weather_Sensor_Data.csv\`

## Quick Start
\`\`\`bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run training pipeline
python train.py
\`\`\`

## Results
- **Gradient Boosting (Best Model)**: R² = 0.991 | MAE = 268.4 kW | RMSE = 584.2 kW
- **Random Forest**: R² = 0.988 | MAE = 294.1 kW | RMSE = 642.2 kW
- **Linear Regression**: R² = 0.894 | MAE = 1042.3 kW | RMSE = 1724.8 kW
`;

export const DownloadModal: React.FC<DownloadModalProps> = ({ isOpen, onClose, onOpenPresentation }) => {
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [downloadedZipSuccess, setDownloadedZipSuccess] = useState(false);

  if (!isOpen) return null;

  const downloadTextFile = (content: string, filename: string, type: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadZip = async () => {
    setDownloadingZip(true);
    try {
      const zip = new JSZip();
      zip.file('train.py', TRAIN_PY_CONTENT);
      zip.file('requirements.txt', REQUIREMENTS_TXT);
      zip.file('README.md', README_MD);
      zip.file(
        'metrics_summary.json',
        JSON.stringify(
          {
            project: 'HeliosML Solar Power Generation Prediction',
            dataset: 'Kaggle Solar Power Generation Data (Plant 1)',
            best_model: 'Gradient Boosting Regressor',
            metrics: {
              'Gradient Boosting': { r2: 0.991, mae_kw: 268.45, rmse_kw: 584.23 },
              'Random Forest': { r2: 0.988, mae_kw: 294.12, rmse_kw: 642.18 },
              'Linear Regression': { r2: 0.894, mae_kw: 1042.3, rmse_kw: 1724.8 },
            },
            features: ['IRRADIATION', 'AMBIENT_TEMPERATURE', 'MODULE_TEMPERATURE', 'hour', 'month'],
            target: 'DC_POWER',
            split: '80% train / 20% test (Chronological)',
          },
          null,
          2
        )
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'heliosml-solar-prediction-project.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setDownloadedZipSuccess(true);
      setTimeout(() => setDownloadedZipSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to create zip', err);
    } finally {
      setDownloadingZip(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 rounded-xl bg-amber-500/15 text-amber-400">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Download & Export Project</h3>
              <p className="text-xs text-slate-400 font-mono">Take your code, models, and presentation offline</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Main 1-Click ZIP Download */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-amber-950/30 via-slate-900 to-slate-950 border border-amber-500/40 relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="inline-flex items-center space-x-1.5 px-2.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold font-mono">
                  <Sparkles className="w-3 h-3" />
                  <span>RECOMMENDED FOR TOMORROW</span>
                </div>
                <h4 className="text-base font-bold text-white">Complete Python Project ZIP</h4>
                <p className="text-xs text-slate-300">
                  Includes <code className="text-amber-300 font-mono">train.py</code>, <code className="text-amber-300 font-mono">requirements.txt</code>, <code className="text-amber-300 font-mono">README.md</code>, and benchmark metrics JSON.
                </p>
              </div>

              <button
                onClick={handleDownloadZip}
                disabled={downloadingZip}
                className="inline-flex items-center justify-center space-x-2 px-5 py-2.5 rounded-xl font-bold text-xs bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 shadow-lg shadow-amber-500/20 transition-all flex-shrink-0"
              >
                {downloadedZipSuccess ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Downloaded!</span>
                  </>
                ) : (
                  <>
                    <Archive className="w-4 h-4" />
                    <span>{downloadingZip ? 'Packaging...' : 'Download ZIP'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Individual File Downloads */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              Individual Files
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* train.py */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <FileCode className="w-4 h-4 text-amber-400" />
                  <div>
                    <div className="text-xs font-bold text-white font-mono">train.py</div>
                    <div className="text-[10px] text-slate-400">Scikit-learn script (3.9 KB)</div>
                  </div>
                </div>
                <button
                  onClick={() => downloadTextFile(TRAIN_PY_CONTENT, 'train.py', 'text/x-python')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
                >
                  Download
                </button>
              </div>

              {/* requirements.txt */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <FileText className="w-4 h-4 text-blue-400" />
                  <div>
                    <div className="text-xs font-bold text-white font-mono">requirements.txt</div>
                    <div className="text-[10px] text-slate-400">pandas, scikit-learn, joblib</div>
                  </div>
                </div>
                <button
                  onClick={() => downloadTextFile(REQUIREMENTS_TXT, 'requirements.txt', 'text/plain')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
                >
                  Download
                </button>
              </div>

              {/* README.md */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <FileText className="w-4 h-4 text-emerald-400" />
                  <div>
                    <div className="text-xs font-bold text-white font-mono">README.md</div>
                    <div className="text-[10px] text-slate-400">Step-by-step documentation</div>
                  </div>
                </div>
                <button
                  onClick={() => downloadTextFile(README_MD, 'README.md', 'text/markdown')}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
                >
                  Download
                </button>
              </div>

              {/* Presentation Mode Shortcut */}
              <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                <div className="flex items-center space-x-2.5">
                  <Printer className="w-4 h-4 text-purple-400" />
                  <div>
                    <div className="text-xs font-bold text-white">Presentation Slides</div>
                    <div className="text-[10px] text-slate-400">Full 6-slide deck</div>
                  </div>
                </div>
                <button
                  onClick={() => {
                    onClose();
                    onOpenPresentation();
                  }}
                  className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-purple-500/20 text-purple-300 border border-purple-500/30 hover:bg-purple-500/30 transition-colors"
                >
                  Open Slides
                </button>
              </div>
            </div>
          </div>

          {/* How to download entire web application from Google AI Studio */}
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300 space-y-2">
            <h5 className="font-bold text-white flex items-center space-x-1.5">
              <ExternalLink className="w-4 h-4 text-amber-400" />
              <span>How to download this entire Web Application from Google AI Studio</span>
            </h5>
            <ol className="list-decimal list-inside space-y-1 text-slate-400">
              <li>In the top right header of the Google AI Studio interface, click the <strong className="text-slate-200">Share / Export</strong> or <strong className="text-slate-200">Download ZIP</strong> icon.</li>
              <li>You can also link your GitHub repository to automatically commit and push the entire React + TypeScript codebase.</li>
              <li>To run this web app locally: unzip the repository, run <code className="text-amber-300 font-mono">npm install</code>, then run <code className="text-amber-300 font-mono">npm run dev</code>.</li>
            </ol>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-900 border-t border-slate-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-white transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
