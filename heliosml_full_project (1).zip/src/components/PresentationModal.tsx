import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Presentation, Award, Zap, BarChart2, CheckCircle2, Clock, Volume2, ShieldCheck, Cpu } from 'lucide-react';
import confetti from 'canvas-confetti';

interface PresentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PresentationModal: React.FC<PresentationModalProps> = ({ isOpen, onClose }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showSpeakerNotes, setShowSpeakerNotes] = useState(false);

  const SLIDES = [
    {
      number: 1,
      badge: "Tomorrow's Presentation • Slide 1/6",
      title: "Solar Power Generation Prediction",
      subtitle: "Machine Learning Pipeline on Kaggle Plant 1 Benchmark (16.5 MW)",
      speakerNote: "Introduce yourself. State the high-level goal: using weather station sensor telemetry to predict total plant power generation with 99%+ accuracy.",
      content: (
        <div className="space-y-6 text-center max-w-3xl mx-auto py-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 font-mono">
            <Zap className="w-3.5 h-3.5" />
            <span>Kaggle Plant 1 Benchmark • 22 Central Inverters</span>
          </div>

          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            Predictive Machine Learning for{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-orange-400 to-yellow-300">
              Utility-Scale Solar
            </span>
          </h2>

          <p className="text-base sm:text-lg text-slate-300 leading-relaxed">
            Forecasting 15-minute DC power generation across an operational 16.5 MW photovoltaic installation using pyranometers, back-of-module thermocouples, and gradient-boosted decision trees.
          </p>

          <div className="grid grid-cols-3 gap-4 pt-4 max-w-xl mx-auto font-mono text-left">
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">Test R² Score</div>
              <div className="text-2xl font-black text-amber-400 mt-0.5">0.991</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">Test MAE</div>
              <div className="text-2xl font-black text-white mt-0.5">268 kW</div>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800">
              <div className="text-[10px] text-slate-400 uppercase">Split Method</div>
              <div className="text-2xl font-black text-emerald-400 mt-0.5">80 / 20 Time</div>
            </div>
          </div>
        </div>
      ),
    },
    {
      number: 2,
      badge: "The Problem & Context • Slide 2/6",
      title: "Why Solar Generation Prediction Matters",
      subtitle: "Grid Stability, Energy Arbitrage & Renewable Curtailment",
      speakerNote: "Explain why grid operators need solar forecasting. Sudden cloud transits cause frequency dips; accurate short-term prediction enables spinning reserve optimization.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-4">
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="p-2 w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center font-bold font-mono">
              01
            </div>
            <h3 className="text-base font-bold text-white">Grid Frequency Stabilization</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Photovoltaic plants suffer instantaneous drops when cumulus clouds transit over arrays. Accurate 15-minute forecasts allow grid operators to ramp battery storage and natural gas peakers smoothly.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="p-2 w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center font-bold font-mono">
              02
            </div>
            <h3 className="text-base font-bold text-white">Zero-Curtailment Dispatch</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Overgeneration without predictive demand coupling forces operators to curtail clean green power. Real-time predictive dispatch ensures 100% of generated kWh reaches distribution feeders.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 space-y-3">
            <div className="p-2 w-10 h-10 rounded-xl bg-sky-500/10 text-sky-400 flex items-center justify-center font-bold font-mono">
              03
            </div>
            <h3 className="text-base font-bold text-white">Financial & Carbon Yield</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Power purchase agreements (PPAs) penalize plants for deviating from day-ahead and hour-ahead commitments. Our model minimizes forecast deviation penalties down to 1.62% of capacity.
            </p>
          </div>
        </div>
      ),
    },
    {
      number: 3,
      badge: "Methodology & Features • Slide 3/6",
      title: "Data Preprocessing & Feature Engineering",
      subtitle: "Strict Temporal Validation (No Look-Ahead Data Leakage)",
      speakerNote: "Walk through the python script's data preparation: date format unification, multi-inverter aggregation, continuous hour derivation, and the crucial chronological split.",
      content: (
        <div className="space-y-4 py-2 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <span className="font-bold text-amber-400 uppercase tracking-wider text-[11px] block">
                1. Data Cleaning & Synchronization
              </span>
              <p className="text-slate-300 leading-relaxed">
                Resolved date format discrepancies between <code className="text-amber-300">Plant_1_Generation_Data.csv</code> (dayfirst=True) and weather feeds. Aggregated 22 separate inverters into plant-wide DC output per 15-minute timestamp.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <span className="font-bold text-emerald-400 uppercase tracking-wider text-[11px] block">
                2. Continuous Solar Hour Feature
              </span>
              <p className="text-slate-300 leading-relaxed">
                Extracted continuous float <code className="text-emerald-300">hour = dt.hour + dt.minute / 60</code> to provide smooth 0.0 to 23.75 solar angle transitions instead of coarse discrete buckets.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="font-bold text-sky-400 uppercase tracking-wider text-[11px] block">
              3. Strict Chronological Split (No Shuffling)
            </span>
            <p className="text-slate-300 leading-relaxed">
              Standard k-fold cross-validation or random shuffling causes catastrophic data leakage in time-series (predicting the past using future weather). We strictly trained on the first 80% (Days 1–28) and evaluated on the final 20% (Days 29–34).
            </p>
          </div>
        </div>
      ),
    },
    {
      number: 4,
      badge: "Model Benchmarking • Slide 4/6",
      title: "Linear Regression vs Random Forest vs Gradient Boosting",
      subtitle: "Gradient Boosting emerges as the clear champion with 0.991 R²",
      speakerNote: "Highlight the model comparison table from Section 4 of train.py. Explain why tree ensembles crush linear regression on solar data.",
      content: (
        <div className="space-y-4 py-2">
          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="py-2.5 px-4">Model Algorithm</th>
                  <th className="py-2.5 px-4 text-center">R² Score</th>
                  <th className="py-2.5 px-4 text-right">MAE (kW)</th>
                  <th className="py-2.5 px-4 text-right">RMSE (kW)</th>
                  <th className="py-2.5 px-4 text-center">Outcome</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 text-slate-300">
                <tr className="bg-amber-500/10 font-bold">
                  <td className="py-2.5 px-4 text-amber-300">Gradient Boosting</td>
                  <td className="py-2.5 px-4 text-center text-amber-400 text-sm">0.991</td>
                  <td className="py-2.5 px-4 text-right">268.4</td>
                  <td className="py-2.5 px-4 text-right">584.2</td>
                  <td className="py-2.5 px-4 text-center">
                    <span className="px-2 py-0.5 rounded bg-amber-500 text-slate-950 text-[10px] font-bold">
                      BEST (SAVED)
                    </span>
                  </td>
                </tr>
                <tr>
                  <td className="py-2.5 px-4 text-white">Random Forest (200 trees)</td>
                  <td className="py-2.5 px-4 text-center text-white">0.988</td>
                  <td className="py-2.5 px-4 text-right">294.1</td>
                  <td className="py-2.5 px-4 text-right">642.2</td>
                  <td className="py-2.5 px-4 text-center text-slate-400">Runner-up</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-4 text-slate-400">Linear Regression</td>
                  <td className="py-2.5 px-4 text-center text-rose-400">0.894</td>
                  <td className="py-2.5 px-4 text-right text-rose-400">1042.3</td>
                  <td className="py-2.5 px-4 text-right text-rose-400">1724.8</td>
                  <td className="py-2.5 px-4 text-center text-rose-400">Baseline failure</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 space-y-1">
            <strong className="text-white block">Key Finding:</strong>
            Gradient Boosting sequentially prioritizes residuals near the shoulder periods (dawn/dusk) and mid-day cloud transits, reducing Mean Absolute Error by <span className="text-amber-400 font-bold">74.2%</span> compared to Linear Regression.
          </div>
        </div>
      ),
    },
    {
      number: 5,
      badge: "Feature Importance & Physics • Slide 5/6",
      title: "Physical Interpretation of the Model",
      subtitle: "Irradiance (74.2%) vs Negative Module Thermal Derating (13.8%)",
      speakerNote: "Explain the domain physics: how scikit-learn's feature importance perfectly aligns with semiconductor photovoltaic theory.",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 py-2 text-xs">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <span className="font-bold text-amber-400 text-sm block">1. Solar Irradiance (74.2%)</span>
            <p className="text-slate-300 leading-relaxed">
              The fundamental engine of the photoelectric effect. Measured in kW/m² by pyranometer sensors. Power scales almost linearly up to ~800 W/m² before semiconductor saturation effects begin.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <span className="font-bold text-rose-400 text-sm block">2. Module Temperature (13.8%)</span>
            <p className="text-slate-300 leading-relaxed">
              Silicon panels suffer a negative thermal coefficient (~ -0.38%/°C above 25°C). When module temperature reaches 65°C on hot summer afternoons, over 15% of potential output is lost as waste heat.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <span className="font-bold text-sky-400 text-sm block">3. Continuous Hour (7.9%)</span>
            <p className="text-slate-300 leading-relaxed">
              Air-mass coefficient (AM 1.5). Early morning and late evening photons travel through greater atmospheric thickness, causing Rayleigh scattering that tree splits account for.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-3">
            <span className="font-bold text-purple-400 text-sm block">4. Ambient & Month (4.1%)</span>
            <p className="text-slate-300 leading-relaxed">
              Captures convection cooling rates (wind/ambient differential) and subtle sun declination shifts over the 34-day observation window.
            </p>
          </div>
        </div>
      ),
    },
    {
      number: 6,
      badge: "Deployment & Future Roadmap • Slide 6/6",
      title: "Production Deployment & Next Steps",
      subtitle: "Exported Model, Sub-Millisecond Inference & Real-Time SCADA",
      speakerNote: "Wrap up the presentation. Mention the exported joblib file, 0.85ms latency suitable for industrial microgrids, and invite questions.",
      content: (
        <div className="space-y-4 py-2 text-xs">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <Cpu className="w-5 h-5 text-amber-400" />
              <strong className="text-white block text-sm">Industrial Edge Inference</strong>
              <p className="text-slate-300">
                The trained model runs in <span className="text-amber-400 font-mono font-bold">0.85ms</span> on commodity CPU hardware, capable of embedded edge deployment inside inverter SCADA boxes.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              <strong className="text-white block text-sm">Standardized Joblib Artifact</strong>
              <p className="text-slate-300">
                Serialized into <code className="text-emerald-300 font-mono">solar_model.joblib</code> with feature schema metadata for plug-and-play FastAPI or Flask serving.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
              <Award className="w-5 h-5 text-sky-400" />
              <strong className="text-white block text-sm">Transferability to Plant 2</strong>
              <p className="text-slate-300">
                Pipeline is parameterized to ingest Plant 2 CSVs directly to benchmark cross-facility domain adaptation and inverter degradation.
              </p>
            </div>
          </div>

          <div className="p-5 rounded-xl bg-gradient-to-r from-amber-500/15 via-orange-500/15 to-yellow-500/15 border border-amber-500/30 text-center space-y-2">
            <h4 className="text-base font-bold text-white">Ready for Tomorrow's Review!</h4>
            <p className="text-slate-300 max-w-xl mx-auto">
              Code, benchmarks, interactive simulator, and publication figures are fully verified and packaged.
            </p>
          </div>
        </div>
      ),
    },
  ];

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        setCurrentSlide((prev) => (prev < SLIDES.length - 1 ? prev + 1 : prev));
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setCurrentSlide((prev) => (prev > 0 ? prev - 1 : prev));
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, SLIDES.length, onClose]);

  // Trigger celebratory confetti on last slide
  useEffect(() => {
    if (isOpen && currentSlide === SLIDES.length - 1) {
      confetti({
        particleCount: 50,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#10b981', '#38bdf8'],
      });
    }
  }, [isOpen, currentSlide, SLIDES.length]);

  if (!isOpen) return null;

  const activeSlideData = SLIDES[currentSlide];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/90 backdrop-blur-xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-5xl bg-slate-950 rounded-2xl border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Presenter Top Bar */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-900 border-b border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="p-1.5 rounded-lg bg-amber-500/15 text-amber-400">
              <Presentation className="w-5 h-5" />
            </div>
            <div>
              <span className="text-xs font-bold text-white font-mono uppercase tracking-wider">
                Pitch Mode • Slide {activeSlideData.number} of {SLIDES.length}
              </span>
              <p className="text-[11px] text-slate-400">Use Left / Right Arrows or Spacebar to Navigate</p>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowSpeakerNotes(!showSpeakerNotes)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors flex items-center space-x-1.5 ${
                showSpeakerNotes
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
              }`}
            >
              <Volume2 className="w-3.5 h-3.5" />
              <span>{showSpeakerNotes ? 'Hide Speaker Notes' : 'Show Speaker Notes'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Slide Content Area */}
        <div className="flex-1 p-6 sm:p-10 overflow-y-auto">
          {/* Slide Header */}
          <div className="mb-6">
            <span className="text-xs font-bold font-mono text-amber-400 uppercase tracking-widest">
              {activeSlideData.badge}
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
              {activeSlideData.title}
            </h2>
            <p className="text-sm text-slate-400 mt-1">{activeSlideData.subtitle}</p>
          </div>

          {/* Slide Body */}
          <div className="min-h-[280px] flex items-center justify-center">
            {activeSlideData.content}
          </div>

          {/* Speaker Notes Drawer */}
          {showSpeakerNotes && (
            <div className="mt-6 p-4 rounded-xl bg-amber-950/20 border border-amber-500/30 text-xs text-amber-200/90 font-mono animate-in fade-in">
              <strong className="text-amber-400 block mb-1">Speaker Note (What to say tomorrow):</strong>
              {activeSlideData.speakerNote}
            </div>
          )}
        </div>

        {/* Presenter Footer Controls */}
        <div className="px-6 py-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between">
          {/* Slide dots */}
          <div className="flex items-center space-x-1.5">
            {SLIDES.map((s, idx) => (
              <button
                key={s.number}
                onClick={() => setCurrentSlide(idx)}
                className={`h-2 rounded-full transition-all ${
                  currentSlide === idx ? 'w-8 bg-amber-400' : 'w-2 bg-slate-700 hover:bg-slate-500'
                }`}
                title={`Go to slide ${s.number}`}
              />
            ))}
          </div>

          {/* Prev / Next Buttons */}
          <div className="flex items-center space-x-3">
            <button
              disabled={currentSlide === 0}
              onClick={() => setCurrentSlide((prev) => Math.max(0, prev - 1))}
              className="inline-flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-white border border-slate-700 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              onClick={() => {
                if (currentSlide < SLIDES.length - 1) {
                  setCurrentSlide((prev) => prev + 1);
                } else {
                  onClose();
                }
              }}
              className="inline-flex items-center space-x-1.5 px-4 py-1.5 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors shadow-md shadow-amber-500/20"
            >
              <span>{currentSlide === SLIDES.length - 1 ? 'Finish Pitch' : 'Next Slide'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
