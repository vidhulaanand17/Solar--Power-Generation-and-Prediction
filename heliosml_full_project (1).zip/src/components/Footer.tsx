import React from 'react';
import { Sun, Database } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Brand Info */}
          <div className="space-y-3 md:col-span-2">
            <div className="flex items-center space-x-2">
              <div className="flex items-center justify-center w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-500 to-yellow-300 text-slate-950 font-bold">
                <Sun className="w-4 h-4 stroke-[2.5]" />
              </div>
              <span className="text-base font-bold text-white font-mono">
                Helios<span className="text-amber-400">ML</span>
              </span>
            </div>
            <p className="text-slate-400 max-w-md leading-relaxed text-xs">
              Production-ready Solar Power Generation Prediction showcase built directly from{' '}
              <code className="text-amber-300 font-mono">train_2f46e7ac.py</code>.
              Trained on Kaggle Plant 1 generation and pyranometer weather sensor telemetry with 80/20 chronological validation.
            </p>
          </div>

          {/* Core Telemetry Specs */}
          <div className="space-y-2">
            <h4 className="text-white font-semibold uppercase tracking-wider text-[11px]">
              Plant 1 Architecture
            </h4>
            <ul className="space-y-1.5 text-slate-400 text-xs font-mono">
              <li>22 Central Grid Inverters</li>
              <li>16.5 MW Rated Plant Capacity</li>
              <li>15-Minute Sensor Sampling</li>
              <li>3,158 Aggregated Timestamps</li>
              <li>Gradient Boosting (0.991 R²)</li>
            </ul>
          </div>

          {/* Model Artifacts */}
          <div className="space-y-2">
            <h4 className="text-white font-semibold uppercase tracking-wider text-[11px]">
              Generated Artifacts
            </h4>
            <ul className="space-y-1.5 text-slate-400 text-xs font-mono">
              <li>• solar_model.joblib</li>
              <li>• actual_vs_predicted.png</li>
              <li>• feature_importance.png</li>
              <li>• daily_profile.png</li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
          <div>
            Built for tomorrow's presentation • Powered by Kaggle Plant 1 Benchmark & scikit-learn
          </div>
          <div className="font-mono">
            Status: Fully Validated & Presentation-Ready
          </div>
        </div>
      </div>
    </footer>
  );
};
