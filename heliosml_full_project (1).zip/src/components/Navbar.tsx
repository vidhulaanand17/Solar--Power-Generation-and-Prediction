import React from 'react';
import { Sun, BarChart2, Cpu, Database, Presentation } from 'lucide-react';

interface NavbarProps {
  onOpenPresentation: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenPresentation,
  activeSection,
  onNavigate,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-md bg-slate-950/85 border-b border-slate-800/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Project Badge */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('hero')}>
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-orange-500 to-yellow-300 shadow-lg shadow-amber-500/20">
              <Sun className="w-5 h-5 text-slate-950 stroke-[2.2]" />
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-bold tracking-tight text-white font-mono">
                  Helios<span className="text-amber-400">ML</span>
                </span>
                <span className="px-2 py-0.5 text-[10px] font-semibold tracking-wider uppercase rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30">
                  Plant 1 Model
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-mono">Solar Power Prediction • R² 0.991</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
            {[
              { id: 'simulator', label: 'Live Predictor', icon: Cpu },
              { id: 'benchmark', label: 'Model Benchmark', icon: BarChart2 },
              { id: 'curves', label: '3-Day Test Curve', icon: Sun },
              { id: 'dataset', label: 'Dataset Explorer', icon: Database },
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Action CTAs */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            {/* Presentation Mode Button */}
            <button
              onClick={onOpenPresentation}
              className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 shadow-md shadow-amber-500/20 transition-all transform active:scale-95"
            >
              <Presentation className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Pitch Slides</span>
              <span className="hidden lg:inline-block px-1.5 py-0.2 rounded bg-black/20 text-[10px] font-mono">
                Tomorrow
              </span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
