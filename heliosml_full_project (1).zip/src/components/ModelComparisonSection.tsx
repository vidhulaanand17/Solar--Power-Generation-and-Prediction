import React, { useState } from 'react';
import { BarChart2, Award, Zap, CheckCircle2, XCircle, ArrowUpRight, Cpu, FileCode2 } from 'lucide-react';
import { MODEL_BENCHMARKS } from '../data/solarData';

export const ModelComparisonSection: React.FC = () => {
  const [selectedMetric, setSelectedMetric] = useState<'r2' | 'mae' | 'rmse'>('r2');

  return (
    <section id="benchmark" className="py-16 border-b border-slate-800/80 bg-slate-950/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 font-medium mb-2">
              <Award className="w-3.5 h-3.5" />
              <span>Section 4 Evaluation Benchmark</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Model Comparison & Selection Matrix
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Comparative benchmark across three candidate algorithms on the chronological 20% test split.
              Gradient Boosting achieved highest test R² and was automatically dumped into <code className="text-amber-300 font-mono text-xs">solar_model.joblib</code>.
            </p>
          </div>

          {/* Metric Selector Pills */}
          <div className="flex items-center space-x-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            {[
              { id: 'r2', label: 'R² Score (Higher is better)' },
              { id: 'mae', label: 'MAE kW (Lower is better)' },
              { id: 'rmse', label: 'RMSE kW (Lower is better)' },
            ].map((m) => (
              <button
                key={m.id}
                onClick={() => setSelectedMetric(m.id as any)}
                className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
                  selectedMetric === m.id
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3 Model Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {MODEL_BENCHMARKS.map((model) => (
            <div
              key={model.name}
              className={`rounded-2xl p-6 border relative transition-all ${
                model.highlight
                  ? 'bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/20 border-amber-500/50 shadow-xl shadow-amber-500/5'
                  : 'bg-slate-900/60 border-slate-800'
              }`}
            >
              {model.highlight && (
                <div className="absolute -top-3 left-6">
                  <span className="inline-flex items-center space-x-1.5 px-3 py-0.5 rounded-full bg-gradient-to-r from-amber-500 to-orange-500 text-slate-950 text-[11px] font-bold shadow-md shadow-amber-500/20">
                    <Award className="w-3.5 h-3.5 stroke-[2.5]" />
                    <span>CHOSEN MODEL</span>
                  </span>
                </div>
              )}

              <div className="flex items-start justify-between mb-4 pt-1">
                <div>
                  <h3 className="text-lg font-bold text-white flex items-center space-x-2">
                    <span>{model.name}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-mono mt-0.5 truncate max-w-[220px]">
                    {model.algorithm}
                  </p>
                </div>
              </div>

              {/* 3 Metrics Block */}
              <div className="grid grid-cols-3 gap-2 py-3 px-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 mb-5 font-mono text-center">
                <div>
                  <div className="text-[10px] text-slate-400 uppercase">R² Score</div>
                  <div className={`text-base font-extrabold mt-0.5 ${model.highlight ? 'text-amber-400' : 'text-white'}`}>
                    {model.r2.toFixed(3)}
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-slate-400 uppercase">MAE (kW)</div>
                  <div className="text-base font-extrabold text-white mt-0.5">
                    {model.mae.toFixed(1)}
                  </div>
                </div>

                <div>
                  <div className="text-[10px] text-slate-400 uppercase">RMSE (kW)</div>
                  <div className="text-base font-extrabold text-white mt-0.5">
                    {model.rmse.toFixed(1)}
                  </div>
                </div>
              </div>

              {/* Relative Bar Representation */}
              <div className="space-y-2 mb-5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-400">
                    {selectedMetric === 'r2'
                      ? 'R² Accuracy'
                      : selectedMetric === 'mae'
                      ? 'Mean Absolute Error'
                      : 'Root Mean Squared Error'}
                  </span>
                  <span className="font-mono font-bold text-slate-200">
                    {selectedMetric === 'r2'
                      ? `${(model.r2 * 100).toFixed(1)}%`
                      : `${model[selectedMetric]} kW`}
                  </span>
                </div>
                <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                  <div
                    className={`h-2 rounded-full transition-all duration-500 ${
                      model.highlight ? 'bg-amber-400' : 'bg-slate-400'
                    }`}
                    style={{
                      width:
                        selectedMetric === 'r2'
                          ? `${(model.r2 / 1.0) * 100}%`
                          : selectedMetric === 'mae'
                          ? `${100 - (model.mae / 1200) * 100}%`
                          : `${100 - (model.rmse / 2000) * 100}%`,
                    }}
                  />
                </div>
              </div>

              {/* Strengths & Tradeoffs */}
              <div className="space-y-2 text-xs border-t border-slate-800 pt-4 text-slate-300">
                <div className="flex items-start space-x-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                  <span>{model.strengths}</span>
                </div>
                <div className="flex items-start space-x-2 text-slate-400">
                  <XCircle className="w-4 h-4 text-rose-400/80 flex-shrink-0 mt-0.5" />
                  <span>{model.drawbacks}</span>
                </div>
              </div>

              {/* Bottom metadata */}
              <div className="mt-5 pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400 font-mono">
                <span>Training: {model.trainingTimeSec}s</span>
                <span>Latency: {model.inferenceLatencyMs}ms</span>
              </div>
            </div>
          ))}
        </div>

        {/* Deep Dive: Why Gradient Boosting Outperforms Linear Models */}
        <div className="rounded-2xl bg-slate-900/90 border border-slate-800 p-6">
          <h3 className="text-base font-bold text-white mb-3 flex items-center space-x-2">
            <Cpu className="w-4 h-4 text-amber-400" />
            <span>Technical Analysis: Photovoltaic Physics vs Regressors</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-slate-300 leading-relaxed">
            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <strong className="text-white block text-sm mb-1">1. Non-linear Thermal Loss</strong>
              Solar panels don't generate power linearly with temperature. While more sunlight increases short-circuit current (I_sc), high module heat steeply degrades open-circuit voltage (V_oc) at approx <span className="text-rose-400 font-mono">-0.38%/°C</span>. Decision tree splits capture this tipping point effortlessly.
            </div>

            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <strong className="text-white block text-sm mb-1">2. Zero-Irradiance Night Step</strong>
              Linear regression attempts to fit a single continuous plane through both noon (16,000 kW) and night (0 kW). This causes negative predictions during darkness unless manually hard-clamped. Tree ensembles naturally partition night into pure zero-leaf clusters.
            </div>

            <div className="p-4 rounded-xl bg-slate-950/60 border border-slate-800/80">
              <strong className="text-white block text-sm mb-1">3. Inverter Saturation Knee</strong>
              Central inverters experience clipping at maximum AC output capacity during cold, ultra-clear days. Gradient boosting naturally learns flat horizontal ceilings at the 16.5 MW boundary without manual clipping constraints.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
