import React, { useState } from 'react';
import { BarChart3, Sun, Activity, Layers, Info, Thermometer } from 'lucide-react';
import { FEATURE_IMPORTANCES, DIURNAL_PROFILE, DiurnalPoint } from '../data/solarData';

export const VisualizationsGallery: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'importance' | 'profile' | 'correlation'>('importance');
  const [hoveredHour, setHoveredHour] = useState<DiurnalPoint | null>(null);

  // Diurnal profile SVG dimensions
  const svgW = 800;
  const svgH = 300;
  const pad = { top: 25, right: 30, bottom: 45, left: 60 };
  const gW = svgW - pad.left - pad.right;
  const gH = svgH - pad.top - pad.bottom;
  const maxKw = 17000;

  const getProfileX = (hour: number) => pad.left + (hour / 23) * gW;
  const getProfileY = (kw: number) => pad.top + gH - (kw / maxKw) * gH;

  const profilePath = DIURNAL_PROFILE.reduce((acc, pt, i) => {
    const x = getProfileX(pt.hour);
    const y = getProfileY(pt.meanPowerKw);
    return i === 0 ? `M ${x} ${y}` : `${acc} L ${x} ${y}`;
  }, '');

  const profileArea = `${profilePath} L ${getProfileX(23)} ${pad.top + gH} L ${getProfileX(0)} ${pad.top + gH} Z`;

  return (
    <section id="visualizations" className="py-16 border-b border-slate-800/80 bg-slate-900/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 font-medium mb-2">
              <Layers className="w-3.5 h-3.5" />
              <span>Script Plots 2 & 3 • Feature Analysis</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Feature Importance & Diurnal Generation
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Explore why certain variables dominate the machine learning model and inspect the plant-wide 24-hour mean generation curve.
            </p>
          </div>

          {/* Tab selector */}
          <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('importance')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === 'importance'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>Feature Importance</span>
            </button>

            <button
              onClick={() => setActiveTab('profile')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === 'profile'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Sun className="w-3.5 h-3.5" />
              <span>Daily Diurnal Profile</span>
            </button>

            <button
              onClick={() => setActiveTab('correlation')}
              className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg font-medium transition-colors ${
                activeTab === 'correlation'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Thermometer className="w-3.5 h-3.5" />
              <span>Physics Dynamics</span>
            </button>
          </div>
        </div>

        {/* Tab Content */}
        {activeTab === 'importance' && (
          <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800 shadow-xl">
            <div className="flex flex-col lg:flex-row gap-8 items-start">
              {/* Left: Interactive Horizontal Bars (Script feature_importance.png replica) */}
              <div className="w-full lg:w-7/12 space-y-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-800 text-xs">
                  <span className="font-semibold text-white uppercase tracking-wider">
                    Feature Name in train.py
                  </span>
                  <span className="text-slate-400 font-mono">Gini / Split Gain %</span>
                </div>

                <div className="space-y-4">
                  {FEATURE_IMPORTANCES.map((item) => (
                    <div key={item.feature} className="space-y-1.5">
                      <div className="flex justify-between text-xs font-mono">
                        <span className="text-white font-bold">{item.feature}</span>
                        <span className="text-amber-400 font-bold">{item.importance.toFixed(1)}%</span>
                      </div>
                      <div className="w-full bg-slate-900 rounded-full h-3.5 overflow-hidden p-0.5 border border-slate-800">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-500 transition-all duration-700"
                          style={{ width: `${item.importance}%` }}
                        />
                      </div>
                      <p className="text-[11px] text-slate-400 leading-snug">
                        {item.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Right: Technical Explanation of Physics Weights */}
              <div className="w-full lg:w-5/12 bg-slate-900/80 rounded-xl p-5 border border-slate-800 space-y-4 text-xs">
                <h3 className="text-sm font-bold text-white flex items-center space-x-2">
                  <Info className="w-4 h-4 text-amber-400" />
                  <span>Physical Rationale of Importance Weights</span>
                </h3>

                <div className="space-y-3 text-slate-300 leading-relaxed">
                  <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80">
                    <strong className="text-amber-300 block mb-1">IRRADIATION (74.2%):</strong>
                    Directly dictates electron excitation in PV silicon junction. Without irradiance, generation is strictly 0 regardless of temperature.
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80">
                    <strong className="text-rose-300 block mb-1">MODULE_TEMPERATURE (13.8%):</strong>
                    Acts as the primary efficiency dampener. Panels heating from 25°C to 65°C incur an ~15.2% power penalty even at peak irradiance.
                  </div>

                  <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800/80">
                    <strong className="text-sky-300 block mb-1">hour (7.9%):</strong>
                    Encodes sun elevation angle (air mass thickness). At equivalent irradiance, low morning sun angles experience higher module surface reflection than direct noon sun.
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800 shadow-xl">
            <div className="flex justify-between items-center pb-4 mb-4 border-b border-slate-800 text-xs">
              <div>
                <h3 className="font-bold text-white text-sm">Average 24-Hour Diurnal Generation Profile</h3>
                <p className="text-slate-400 text-xs">Replicating <code className="font-mono text-amber-300">df.groupby(df['DATE_TIME'].dt.hour)['DC_POWER'].mean()</code></p>
              </div>
              <span className="font-mono text-slate-400 text-xs">Peak Mean: 15,320 kW @ 12:00</span>
            </div>

            {/* SVG Profile Chart */}
            <div className="relative">
              <svg
                viewBox={`0 0 ${svgW} ${svgH}`}
                className="w-full h-auto cursor-crosshair"
                onMouseMove={(e) => {
                  const rect = e.currentTarget.getBoundingClientRect();
                  const x = (e.clientX - rect.left) * (svgW / rect.width) - pad.left;
                  const ratio = Math.max(0, Math.min(1, x / gW));
                  const hourIndex = Math.round(ratio * 23);
                  setHoveredHour(DIURNAL_PROFILE[hourIndex] || null);
                }}
                onMouseLeave={() => setHoveredHour(null)}
              >
                <defs>
                  <linearGradient id="profileFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#f59e0b" stopOpacity="0.0" />
                  </linearGradient>
                </defs>

                {/* Y Grid */}
                {[0, 4000, 8000, 12000, 16000].map((kw) => {
                  const y = getProfileY(kw);
                  return (
                    <g key={kw}>
                      <line x1={pad.left} y1={y} x2={svgW - pad.right} y2={y} stroke="#1e293b" strokeDasharray="3 3" />
                      <text x={pad.left - 10} y={y + 4} textAnchor="end" fill="#64748b" fontSize="10" fontFamily="monospace">
                        {kw / 1000} MW
                      </text>
                    </g>
                  );
                })}

                {/* Fill Area */}
                <path d={profileArea} fill="url(#profileFill)" />

                {/* Curve */}
                <path d={profilePath} fill="none" stroke="#f59e0b" strokeWidth="2.5" strokeLinecap="round" />

                {/* X Ticks */}
                {[0, 3, 6, 9, 12, 15, 18, 21].map((h) => (
                  <text key={h} x={getProfileX(h)} y={svgH - pad.bottom + 20} textAnchor="middle" fill="#94a3b8" fontSize="10" fontFamily="monospace">
                    {h.toString().padStart(2, '0')}:00
                  </text>
                ))}

                {/* Hover line */}
                {hoveredHour && (
                  <g>
                    <line
                      x1={getProfileX(hoveredHour.hour)}
                      y1={pad.top}
                      x2={getProfileX(hoveredHour.hour)}
                      y2={pad.top + gH}
                      stroke="#ffffff"
                      strokeDasharray="2 2"
                    />
                    <circle
                      cx={getProfileX(hoveredHour.hour)}
                      cy={getProfileY(hoveredHour.meanPowerKw)}
                      r="5"
                      fill="#f59e0b"
                      stroke="#ffffff"
                      strokeWidth="2"
                    />
                  </g>
                )}
              </svg>

              {hoveredHour && (
                <div className="absolute top-2 right-4 p-3 rounded-xl bg-slate-900 border border-slate-700 shadow-xl text-xs font-mono space-y-1">
                  <div className="text-amber-400 font-bold">{hoveredHour.displayHour}</div>
                  <div className="text-white">Mean DC Power: {hoveredHour.meanPowerKw.toLocaleString()} kW</div>
                  <div className="text-slate-400">Mean Irradiance: {hoveredHour.meanIrradiation} kW/m²</div>
                  <div className="text-rose-400">Mean Module Temp: {hoveredHour.meanModuleTemp}°C</div>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'correlation' && (
          <div className="bg-slate-950 rounded-2xl p-6 border border-slate-800 shadow-xl space-y-6">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider">
              Photovoltaic Thermodynamics & Sensor Coupling
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-slate-300">
              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-amber-400 font-semibold text-sm">
                  <Sun className="w-4 h-4" />
                  <span>Irradiance vs Power Linearity</span>
                </div>
                <p>
                  In the lower irradiance bracket (0.0 to 0.7 kW/m²), power output is virtually 1:1 proportional with photon density.
                  As irradiance crosses 0.9 kW/m², back-of-module temperatures routinely exceed 60°C, causing the conversion curve to bend downward due to internal resistance increase.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center space-x-2 text-rose-400 font-semibold text-sm">
                  <Thermometer className="w-4 h-4" />
                  <span>Module vs Ambient Temperature Delta</span>
                </div>
                <p>
                  While ambient air temperature rarely exceeded 38°C during the May–June test period, solar panel module temperature climbed up to 66°C+.
                  The model uses both features simultaneously to infer wind and convective cooling rates.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
