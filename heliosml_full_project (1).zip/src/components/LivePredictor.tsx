import React, { useState, useMemo } from 'react';
import { Sliders, Sun, Thermometer, Clock, Calendar, Zap, Home, Leaf, AlertTriangle, CheckCircle, Info, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { predictSolarPower, PRESET_CONDITIONS, PredictorInput } from '../utils/predictor';

export const LivePredictor: React.FC = () => {
  const [inputs, setInputs] = useState<PredictorInput>({
    irradiation: 0.95,
    ambientTemp: 32.0,
    moduleTemp: 61.5,
    hour: 12.5, // 12:30 PM
    month: 5,   // May
  });

  const [showModelComparison, setShowModelComparison] = useState(true);

  // Calculate prediction dynamically
  const prediction = useMemo(() => {
    return predictSolarPower(inputs);
  }, [inputs]);

  const handlePresetSelect = (presetValues: PredictorInput) => {
    setInputs({ ...presetValues });
    if (presetValues.irradiation > 0.9) {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#f59e0b', '#fbbf24', '#10b981'],
      });
    }
  };

  const formatHourString = (hourDecimal: number) => {
    const h = Math.floor(hourDecimal);
    const m = Math.round((hourDecimal - h) * 60);
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 === 0 ? 12 : h % 12;
    return `${displayH}:${m.toString().padStart(2, '0')} ${period} (${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')})`;
  };

  return (
    <section id="simulator" className="py-16 border-b border-slate-800/80 bg-slate-950/60 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-10 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 font-medium mb-2">
              <Sliders className="w-3.5 h-3.5" />
              <span>Interactive Inference Engine</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Real-Time Solar Power Simulator
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Adjust environmental telemetry features or select operational presets to test the trained Gradient Boosting model against physical solar phenomena.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-xs text-slate-400">Ensemble comparison:</span>
            <button
              onClick={() => setShowModelComparison(!showModelComparison)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                showModelComparison
                  ? 'bg-amber-500/15 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              {showModelComparison ? 'Hide 3-Model Compare' : 'Show 3-Model Compare'}
            </button>
          </div>
        </div>

        {/* Operational Presets Pills */}
        <div className="mb-8">
          <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2.5">
            Operational Weather Presets:
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {PRESET_CONDITIONS.map((preset) => {
              const isSelected =
                Math.abs(inputs.irradiation - preset.values.irradiation) < 0.05 &&
                Math.abs(inputs.hour - preset.values.hour) < 0.5;

              return (
                <button
                  key={preset.id}
                  onClick={() => handlePresetSelect(preset.values)}
                  className={`p-2.5 rounded-xl text-left border transition-all ${
                    isSelected
                      ? 'bg-amber-500/20 border-amber-500 text-white shadow-md shadow-amber-500/10'
                      : 'bg-slate-900/80 hover:bg-slate-800/90 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800/80 text-amber-400 border border-slate-700/50">
                      {preset.badge}
                    </span>
                  </div>
                  <div className="text-xs font-semibold truncate text-white">{preset.name}</div>
                  <div className="text-[10px] text-slate-400 truncate mt-0.5">{preset.description}</div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Main Grid: Feature Controls on Left, Live Output on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: 5 Telemetry Inputs */}
          <div className="lg:col-span-7 bg-slate-900/90 rounded-2xl p-6 border border-slate-800 space-y-6">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center space-x-2 border-b border-slate-800 pb-3">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>Input Features (X Matrix)</span>
            </h3>

            {/* Feature 1: IRRADIATION */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-200 flex items-center space-x-2">
                  <Sun className="w-4 h-4 text-amber-400" />
                  <span>Solar Irradiance (IRRADIATION)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
                    74.2% Importance
                  </span>
                </label>
                <span className="text-sm font-bold text-amber-400 font-mono">
                  {inputs.irradiation.toFixed(2)} <span className="text-xs text-slate-400">kW/m²</span>
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="1.20"
                step="0.01"
                value={inputs.irradiation}
                onChange={(e) => setInputs({ ...inputs, irradiation: parseFloat(e.target.value) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0.00 (Night/Black)</span>
                <span>0.30 (Overcast)</span>
                <span>0.75 (Clear)</span>
                <span>1.05 (Peak Noon)</span>
                <span>1.20 (Extreme)</span>
              </div>
            </div>

            {/* Feature 2: MODULE_TEMPERATURE */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-200 flex items-center space-x-2">
                  <Thermometer className="w-4 h-4 text-rose-400" />
                  <span>Module Surface Temp (MODULE_TEMPERATURE)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/10 text-rose-400 border border-rose-500/20 font-mono">
                    13.8% Importance
                  </span>
                </label>
                <span className="text-sm font-bold text-rose-400 font-mono">
                  {inputs.moduleTemp.toFixed(1)} <span className="text-xs text-slate-400">°C</span>
                </span>
              </div>
              <input
                type="range"
                min="15"
                max="75"
                step="0.5"
                value={inputs.moduleTemp}
                onChange={(e) => setInputs({ ...inputs, moduleTemp: parseFloat(e.target.value) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>15°C (Cool/Night)</span>
                <span>25°C (STC Nominal)</span>
                <span>50°C (Warm)</span>
                <span className="text-rose-400">70°C+ (Severe Derating)</span>
              </div>
            </div>

            {/* Feature 3: AMBIENT_TEMPERATURE */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-200 flex items-center space-x-2">
                  <Thermometer className="w-4 h-4 text-sky-400" />
                  <span>Ambient Air Temp (AMBIENT_TEMPERATURE)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/10 text-sky-400 border border-sky-500/20 font-mono">
                    3.1% Importance
                  </span>
                </label>
                <span className="text-sm font-bold text-sky-400 font-mono">
                  {inputs.ambientTemp.toFixed(1)} <span className="text-xs text-slate-400">°C</span>
                </span>
              </div>
              <input
                type="range"
                min="15"
                max="45"
                step="0.5"
                value={inputs.ambientTemp}
                onChange={(e) => setInputs({ ...inputs, ambientTemp: parseFloat(e.target.value) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-sky-500"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>15°C (Dawn)</span>
                <span>28°C (Pleasant)</span>
                <span>35°C (Hot)</span>
                <span>45°C (Arid Desert)</span>
              </div>
            </div>

            {/* Feature 4: hour */}
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-200 flex items-center space-x-2">
                  <Clock className="w-4 h-4 text-amber-300" />
                  <span>Time of Day (hour = hour + min/60)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
                    7.9% Importance
                  </span>
                </label>
                <span className="text-xs font-bold text-amber-300 font-mono">
                  {formatHourString(inputs.hour)}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="23.75"
                step="0.25"
                value={inputs.hour}
                onChange={(e) => setInputs({ ...inputs, hour: parseFloat(e.target.value) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-yellow-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>00:00</span>
                <span>06:00 (Dawn)</span>
                <span>12:00 (Noon)</span>
                <span>18:00 (Dusk)</span>
                <span>23:45</span>
              </div>
            </div>

            {/* Feature 5: month - All 12 Months */}
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-xs font-semibold text-slate-200 flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-purple-400" />
                  <span>Calendar Month (month: 1 to 12)</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20 font-mono">
                    1.0% Importance
                  </span>
                </label>
                <span className="text-xs font-bold text-purple-300 font-mono">
                  {(() => {
                    const months = [
                      'Jan (January)', 'Feb (February)', 'Mar (March)', 'Apr (April)',
                      'May (Train Split)', 'Jun (Test Split)', 'Jul (July)', 'Aug (August)',
                      'Sep (September)', 'Oct (October)', 'Nov (November)', 'Dec (December)'
                    ];
                    return `Month ${inputs.month}: ${months[inputs.month - 1] || inputs.month}`;
                  })()}
                </span>
              </div>

              {/* Slider for smooth 1-12 scrub */}
              <input
                type="range"
                min="1"
                max="12"
                step="1"
                value={inputs.month}
                onChange={(e) => setInputs({ ...inputs, month: parseInt(e.target.value, 10) })}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-500"
              />

              {/* 12 Months Grid Buttons (Jan through Dec) */}
              <div className="grid grid-cols-4 sm:grid-cols-6 gap-1.5">
                {[
                  { m: 1, short: 'Jan', badge: '' },
                  { m: 2, short: 'Feb', badge: '' },
                  { m: 3, short: 'Mar', badge: '' },
                  { m: 4, short: 'Apr', badge: '' },
                  { m: 5, short: 'May', badge: 'Train' },
                  { m: 6, short: 'Jun', badge: 'Test' },
                  { m: 7, short: 'Jul', badge: '' },
                  { m: 8, short: 'Aug', badge: '' },
                  { m: 9, short: 'Sep', badge: '' },
                  { m: 10, short: 'Oct', badge: '' },
                  { m: 11, short: 'Nov', badge: '' },
                  { m: 12, short: 'Dec', badge: '' },
                ].map((item) => {
                  const isSelected = inputs.month === item.m;
                  return (
                    <button
                      key={item.m}
                      onClick={() => setInputs({ ...inputs, month: item.m })}
                      className={`relative py-1.5 px-2 rounded-lg text-xs font-medium border text-center transition-all ${
                        isSelected
                          ? 'bg-purple-500/25 border-purple-400 text-white shadow-sm shadow-purple-500/20 font-bold'
                          : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-center space-x-1">
                        <span>{item.short}</span>
                        {item.badge && (
                          <span
                            className={`text-[9px] px-1 rounded uppercase font-mono ${
                              item.badge === 'Train'
                                ? 'bg-amber-500/30 text-amber-300'
                                : 'bg-emerald-500/30 text-emerald-300'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-[9px] text-slate-500 font-mono mt-0.5">
                        M{item.m}
                      </div>
                    </button>
                  );
                })}
              </div>

              <div className="flex justify-between text-[10px] text-slate-500 font-mono pt-0.5">
                <span>M1 (January)</span>
                <span className="text-amber-400/90">M5 (May - 80% Train)</span>
                <span className="text-emerald-400/90">M6 (June - 20% Test)</span>
                <span>M12 (December)</span>
              </div>
            </div>
          </div>

          {/* Right Column: Model Output & Telemetry Gauge */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-slate-950 rounded-2xl p-6 border border-slate-800 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
                <div className="flex items-center space-x-2">
                  <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white">Plant Total Generation</h4>
                    <p className="text-[11px] text-slate-400 font-mono">Target: DC_POWER sum across 22 inverters</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    {prediction.capacityFactorPct}% CAPACITY
                  </span>
                </div>
              </div>

              {/* Large Output Display */}
              <div className="p-5 rounded-2xl bg-slate-950/80 border border-slate-800/90 text-center mb-5 relative">
                <div className="text-xs font-medium text-slate-400 uppercase tracking-widest mb-1">
                  Predicted DC Power (Gradient Boosting)
                </div>
                <div className="text-4xl sm:text-5xl font-black text-amber-400 font-mono tracking-tight flex items-baseline justify-center space-x-2">
                  <span>{prediction.dcPowerGbKw.toLocaleString()}</span>
                  <span className="text-lg text-slate-400 font-normal">kW</span>
                </div>
                <div className="text-xs text-slate-400 mt-1 font-mono">
                  {(prediction.dcPowerGbKw / 1000).toFixed(2)} MW of 16.50 MW Peak Rating
                </div>

                {/* Capacity Progress Bar */}
                <div className="w-full bg-slate-800 rounded-full h-2.5 mt-3 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-amber-500 via-orange-500 to-emerald-400 h-2.5 rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, prediction.capacityFactorPct)}%` }}
                  />
                </div>
              </div>

              {/* Secondary Metrics */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                  <div className="text-[11px] text-slate-400 flex items-center space-x-1.5">
                    <Zap className="w-3.5 h-3.5 text-emerald-400" />
                    <span>AC Grid Export</span>
                  </div>
                  <div className="text-lg font-bold text-white font-mono mt-1">
                    {prediction.acPowerKw.toLocaleString()} <span className="text-xs text-slate-400">kW</span>
                  </div>
                  <div className="text-[10px] text-emerald-400 font-mono mt-0.5">
                    {prediction.inverterEfficiencyPct}% Inverter Eff.
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                  <div className="text-[11px] text-slate-400 flex items-center space-x-1.5">
                    <Thermometer className="w-3.5 h-3.5 text-rose-400" />
                    <span>Thermal Derating</span>
                  </div>
                  <div className="text-lg font-bold text-rose-400 font-mono mt-1">
                    -{prediction.thermalDeratingPct}%
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    vs 25°C STC baseline
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                  <div className="text-[11px] text-slate-400 flex items-center space-x-1.5">
                    <Home className="w-3.5 h-3.5 text-sky-400" />
                    <span>Homes Powered</span>
                  </div>
                  <div className="text-lg font-bold text-white font-mono mt-1">
                    {prediction.homesPowered.toLocaleString()}
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    @ 1.25 kW continuous
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
                  <div className="text-[11px] text-slate-400 flex items-center space-x-1.5">
                    <Leaf className="w-3.5 h-3.5 text-emerald-400" />
                    <span>CO₂ Avoided</span>
                  </div>
                  <div className="text-lg font-bold text-emerald-400 font-mono mt-1">
                    {prediction.co2SavedKgPerHour.toLocaleString()} <span className="text-xs text-slate-400">kg/h</span>
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                    Displacing coal grid
                  </div>
                </div>
              </div>

              {/* Status Note Banner */}
              <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-start space-x-2.5 text-xs text-slate-300">
                <Info className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <span>{prediction.statusNote}</span>
              </div>
            </div>

            {/* Model Comparison Card if toggled */}
            {showModelComparison && (
              <div className="bg-slate-900 rounded-2xl p-4 border border-slate-800 space-y-3">
                <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center justify-between">
                  <span>Ensemble Breakdown on Current Input:</span>
                  <span className="text-[10px] font-normal text-slate-400">Model agreement</span>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-amber-400" />
                      <span className="text-xs font-semibold text-white">Gradient Boosting (Champion)</span>
                    </div>
                    <span className="text-xs font-bold text-amber-400 font-mono">
                      {prediction.dcPowerGbKw.toLocaleString()} kW
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-blue-400" />
                      <span className="text-xs font-semibold text-slate-200">Random Forest (200 trees)</span>
                    </div>
                    <span className="text-xs font-bold text-blue-400 font-mono">
                      {prediction.dcPowerRfKw.toLocaleString()} kW
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <div className="flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-slate-400" />
                      <span className="text-xs font-semibold text-slate-300">Linear Regression</span>
                    </div>
                    <span className={`text-xs font-bold font-mono ${prediction.dcPowerLrKw < 0 ? 'text-rose-400' : 'text-slate-300'}`}>
                      {prediction.dcPowerLrKw.toLocaleString()} kW
                      {prediction.dcPowerLrKw < 0 && ' (Negative night error)'}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
