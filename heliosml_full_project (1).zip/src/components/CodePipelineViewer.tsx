import React, { useState } from 'react';
import { Code, Download, Copy, Check, Terminal, FileCode2, ChevronRight, Play } from 'lucide-react';

const RAW_CODE = `"""
Solar Power Generation Prediction - training script

Dataset: Kaggle "Solar Power Generation Data" (Plant 1)
Put these two files in the same folder as this script:
    Plant_1_Generation_Data.csv
    Plant_1_Weather_Sensor_Data.csv

Run:  python train.py
"""

import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

# ---------------------------------------------------------------- 1. Load
gen = pd.read_csv("Plant_1_Generation_Data.csv")
weather = pd.read_csv("Plant_1_Weather_Sensor_Data.csv")

# The two files use different date formats
gen["DATE_TIME"] = pd.to_datetime(gen["DATE_TIME"], dayfirst=True)
weather["DATE_TIME"] = pd.to_datetime(weather["DATE_TIME"])

# Total plant output per timestamp (sum over all inverters)
gen = gen.groupby("DATE_TIME", as_index=False)["DC_POWER"].sum()

df = gen.merge(
    weather[["DATE_TIME", "AMBIENT_TEMPERATURE", "MODULE_TEMPERATURE", "IRRADIATION"]],
    on="DATE_TIME",
    how="inner",
).sort_values("DATE_TIME")

# ---------------------------------------------------------------- 2. Clean + features
df = df.dropna()
df["hour"] = df["DATE_TIME"].dt.hour + df["DATE_TIME"].dt.minute / 60
df["month"] = df["DATE_TIME"].dt.month

FEATURES = ["IRRADIATION", "AMBIENT_TEMPERATURE", "MODULE_TEMPERATURE", "hour", "month"]
TARGET = "DC_POWER"

# ---------------------------------------------------------------- 3. Time-based split (no shuffling)
split = int(len(df) * 0.8)
train, test = df.iloc[:split], df.iloc[split:]
X_train, y_train = train[FEATURES], train[TARGET]
X_test, y_test = test[FEATURES], test[TARGET]

# ---------------------------------------------------------------- 4. Models
models = {
    "Linear Regression": LinearRegression(),
    "Random Forest": RandomForestRegressor(n_estimators=200, random_state=42, n_jobs=-1),
    "Gradient Boosting": GradientBoostingRegressor(random_state=42),
}

results, preds = {}, {}
for name, model in models.items():
    model.fit(X_train, y_train)
    p = model.predict(X_test)
    preds[name] = p
    results[name] = {
        "RMSE": np.sqrt(mean_squared_error(y_test, p)),
        "MAE": mean_absolute_error(y_test, p),
        "R2": r2_score(y_test, p),
    }

results_df = pd.DataFrame(results).T.round(3)
print("\\nModel comparison:\\n", results_df)

best_name = results_df["R2"].idxmax()
best_model = models[best_name]
print(f"\\nBest model: {best_name}")

joblib.dump({"model": best_model, "features": FEATURES}, "solar_model.joblib")

# ---------------------------------------------------------------- 5. Plots
# Actual vs predicted (last 3 days of test set)
n = 96 * 3  # 15-min data -> 96 points per day
plt.figure(figsize=(11, 4))
plt.plot(test["DATE_TIME"].iloc[-n:], y_test.iloc[-n:], label="Actual")
plt.plot(test["DATE_TIME"].iloc[-n:], preds[best_name][-n:], label=f"Predicted ({best_name})")
plt.ylabel("DC power (kW)")
plt.title("Actual vs predicted solar power")
plt.legend()
plt.tight_layout()
plt.savefig("actual_vs_predicted.png", dpi=150)

# Feature importance (tree models only)
if hasattr(best_model, "feature_importances_"):
    imp = pd.Series(best_model.feature_importances_, index=FEATURES).sort_values()
    plt.figure(figsize=(6, 3.5))
    imp.plot(kind="barh")
    plt.title("Feature importance")
    plt.tight_layout()
    plt.savefig("feature_importance.png", dpi=150)

# Daily pattern
plt.figure(figsize=(7, 3.5))
df.groupby(df["DATE_TIME"].dt.hour)[TARGET].mean().plot()
plt.xlabel("Hour of day")
plt.ylabel("Mean DC power (kW)")
plt.title("Average daily generation profile")
plt.tight_layout()
plt.savefig("daily_profile.png", dpi=150)

print("\\nSaved: solar_model.joblib, actual_vs_predicted.png, feature_importance.png, daily_profile.png")`;

export const CodePipelineViewer: React.FC = () => {
  const [copied, setCopied] = useState(false);
  const [activeStepTab, setActiveStepTab] = useState<number>(1);

  const handleCopy = () => {
    navigator.clipboard.writeText(RAW_CODE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const PIPELINE_STEPS = [
    {
      step: 1,
      title: "Data Loading & Format Unification",
      lines: "Lines 20 - 35",
      summary: "Loads generation & weather sensor CSVs; resolves date format discrepancy (`dayfirst=True`), sums DC_POWER over all 22 inverters per timestamp.",
      highlight: "gen.groupby('DATE_TIME', as_index=False)['DC_POWER'].sum()",
    },
    {
      step: 2,
      title: "Feature Engineering & Cleaning",
      lines: "Lines 37 - 43",
      summary: "Drops nulls, derives fractional hour (`hour + minute/60`) and calendar month. Targets DC_POWER total.",
      highlight: "FEATURES = ['IRRADIATION', 'AMBIENT_TEMPERATURE', 'MODULE_TEMPERATURE', 'hour', 'month']",
    },
    {
      step: 3,
      title: "Temporal Train-Test Split",
      lines: "Lines 45 - 50",
      summary: "Crucial time-series discipline: NO random shuffling! Uses first 80% chronologically for training, final 20% for testing.",
      highlight: "split = int(len(df) * 0.8) # Preserves causal arrow of time",
    },
    {
      step: 4,
      title: "Ensemble Training & Evaluation",
      lines: "Lines 51 - 76",
      summary: "Fits Linear Regression, 200-estimator Random Forest, and Gradient Boosting. Computes RMSE, MAE, and R². Serializes best model with joblib.",
      highlight: "joblib.dump({'model': best_model, 'features': FEATURES}, 'solar_model.joblib')",
    },
    {
      step: 5,
      title: "Publication Plot Generation",
      lines: "Lines 78 - 108",
      summary: "Generates 3 publication figures: 72-hour actual vs predicted time series (96*3 points), horizontal feature importances, and diurnal profile.",
      highlight: "plt.savefig('actual_vs_predicted.png', dpi=150)",
    },
  ];

  return (
    <section id="pipeline" className="py-16 border-b border-slate-800/80 bg-slate-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 font-medium mb-2">
              <Code className="w-3.5 h-3.5" />
              <span>Full Python Implementation</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Execution Pipeline & Python Code
            </h2>
            <p className="text-sm text-slate-400 mt-1 max-w-2xl">
              Inspect the end-to-end training architecture implemented in <span className="font-mono text-amber-300">train_2f46e7ac.py</span>.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 border border-slate-800 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4 text-slate-400" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy train.py'}</span>
            </button>

            <a
              href="/assets/aistudio/train_2f46e7ac.py"
              download="train.py"
              className="inline-flex items-center space-x-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors shadow-md shadow-amber-500/20"
            >
              <Download className="w-4 h-4" />
              <span>Download File</span>
            </a>
          </div>
        </div>

        {/* 5-Step Pipeline Flow */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 mb-8">
          {PIPELINE_STEPS.map((step) => {
            const isSelected = activeStepTab === step.step;
            return (
              <button
                key={step.step}
                onClick={() => setActiveStepTab(step.step)}
                className={`p-3.5 rounded-xl text-left border transition-all ${
                  isSelected
                    ? 'bg-amber-500/15 border-amber-500 text-white shadow-md'
                    : 'bg-slate-900/60 hover:bg-slate-900 border-slate-800 text-slate-300'
                }`}
              >
                <div className="flex items-center justify-between text-xs mb-1 font-mono">
                  <span className={`font-bold ${isSelected ? 'text-amber-400' : 'text-slate-400'}`}>
                    Step 0{step.step}
                  </span>
                  <span className="text-[10px] text-slate-500">{step.lines}</span>
                </div>
                <div className="text-xs font-semibold truncate text-white">{step.title}</div>
                <div className="text-[11px] text-slate-400 line-clamp-2 mt-1 leading-snug">
                  {step.summary}
                </div>
              </button>
            );
          })}
        </div>

        {/* Code Terminal Display */}
        <div className="rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden shadow-2xl">
          {/* Terminal Bar */}
          <div className="bg-slate-900/90 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="flex space-x-1.5">
                <span className="w-3 h-3 rounded-full bg-rose-500/80 inline-block" />
                <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
                <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
              </div>
              <span className="text-xs text-slate-400 font-mono ml-2">train_2f46e7ac.py</span>
            </div>

            <div className="flex items-center space-x-3 text-xs text-slate-400 font-mono">
              <span className="hidden sm:inline">scikit-learn 1.4+ • pandas • joblib</span>
              <span className="px-2 py-0.5 rounded bg-slate-800 text-amber-300">Python 3.10+</span>
            </div>
          </div>

          {/* Syntax Highlighted Code Viewer */}
          <div className="p-4 sm:p-6 overflow-x-auto max-h-[500px] text-xs font-mono text-slate-300 leading-relaxed bg-slate-950/90">
            <pre>
              {RAW_CODE.split('\n').map((line, idx) => {
                const lineNum = idx + 1;
                const isComment = line.trim().startsWith('#') || line.trim().startsWith('"""') || line.trim().startsWith('*');
                const isImport = line.startsWith('import ') || line.startsWith('from ');
                const isHeading = line.includes('---');

                return (
                  <div key={idx} className="flex hover:bg-slate-900/50 py-0.5 px-2 rounded">
                    <span className="w-10 text-slate-600 select-none text-right pr-4 font-mono text-[11px]">
                      {lineNum}
                    </span>
                    <span
                      className={
                        isHeading
                          ? 'text-amber-400 font-bold'
                          : isComment
                          ? 'text-slate-500 italic'
                          : isImport
                          ? 'text-purple-400'
                          : line.includes('def ') || line.includes('class ')
                          ? 'text-blue-400 font-semibold'
                          : line.includes('="') || line.includes("='")
                          ? 'text-emerald-400'
                          : 'text-slate-200'
                      }
                    >
                      {line || ' '}
                    </span>
                  </div>
                );
              })}
            </pre>
          </div>
        </div>
      </div>
    </section>
  );
};
