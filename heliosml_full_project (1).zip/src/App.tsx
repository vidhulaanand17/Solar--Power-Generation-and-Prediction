/**
 * HeliosML - Solar Power Generation Prediction
 * Built for Kaggle Plant 1 benchmark presentation
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { LivePredictor } from './components/LivePredictor';
import { ModelComparisonSection } from './components/ModelComparisonSection';
import { ActualVsPredictedChart } from './components/ActualVsPredictedChart';
import { VisualizationsGallery } from './components/VisualizationsGallery';
import { DatasetExplorer } from './components/DatasetExplorer';
import { PresentationModal } from './components/PresentationModal';
import { Footer } from './components/Footer';

export default function App() {
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top sticky navigation */}
      <Navbar
        onOpenPresentation={() => setIsPresentationOpen(true)}
        activeSection={activeSection}
        onNavigate={scrollToSection}
      />

      <main>
        {/* 1. Hero & Evaluation Scorecard */}
        <HeroSection
          onExploreSimulator={() => scrollToSection('simulator')}
          onExploreBenchmark={() => scrollToSection('benchmark')}
          onOpenPresentation={() => setIsPresentationOpen(true)}
        />

        {/* 2. Interactive ML Simulator */}
        <LivePredictor />

        {/* 3. 3-Day Test Curve (Plot 1 from train.py) */}
        <ActualVsPredictedChart />

        {/* 4. Model Comparison Arena (Section 4 from train.py) */}
        <ModelComparisonSection />

        {/* 5. Feature Importance & Diurnal Generation (Plots 2 & 3 from train.py) */}
        <VisualizationsGallery />

        {/* 6. Kaggle Dataset & Plant 1 Architecture Explorer */}
        <DatasetExplorer />
      </main>

      {/* Footer */}
      <Footer />

      {/* Fullscreen Presentation Mode for Tomorrow's Pitch */}
      <PresentationModal
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
      />
    </div>
  );
}
